package com.example.demo.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.demo.entity.BusDetails;
@Repository
public interface BusInterface extends JpaRepository<BusDetails,Integer>{

}
