package com.example.demo.serviceimpl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entity.BusDetails;
import com.example.demo.repository.BusInterface;
import com.example.demo.service.BusService;
@Service
public class BusServiceImpl implements BusService{
	
	@Autowired
	BusInterface busdao;
	
	public List<BusDetails> getAllBusDetails() {
		return busdao.findAll();
	}
    
	//For adding bus details
	@Override
	public BusDetails addBusDetails(BusDetails details) {
		if (details == null) {
			
		}
		Integer busNumber = (int) ((Math.random() * 9000) + 1000);
		details.setBusNumber(busNumber);
		busdao.save(details);
		return details;
	}

	//Deleting Bus By ID
	@Override
	public void deleteBus(Integer busNumber) {
		
		Optional<BusDetails> details = busdao.findById(busNumber);
		
		busdao.deleteById(busNumber);
	}
    
	//Updating the bus details By ID
	@Override
	public BusDetails updateBus(BusDetails details) {
		
			
		Optional<BusDetails> busDetails = busdao.findById(details.getBusNumber());
		
		busdao.save(details);
		return details;
	}
	

}
