package com.example.demo.service;

import java.util.List;

import com.example.demo.entity.BusDetails;

public interface BusService {
	public List<BusDetails> getAllBusDetails();
	public BusDetails addBusDetails(BusDetails details);

	public void deleteBus(Integer busNumber);

	public BusDetails updateBus(BusDetails details);

}
