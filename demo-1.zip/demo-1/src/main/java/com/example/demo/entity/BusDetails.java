package com.example.demo.entity;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table
@Data @NoArgsConstructor @AllArgsConstructor
public class BusDetails {
	@Id
	private Integer busNumber;

	
	private String departureBusstop;

	
	private String arrivalBusstop;

	private Integer availableSeats;

	
	private String departureDate;

	
	private String arrivalDate;

	
	private String arrivalTime;

	
	private String departureTime;

	
	private String busVendor;

	
	private Double cost;
	
	public BusDetails(
			 String departureBusstop,
			 String arrivalBusstop, Integer availableSeats,
			String departureDate,
			 String arrivalDate,
			 String arrivalTime,
			 String departureTime,
			String busVendor, Double cost) {
		super();
		this.departureBusstop = departureBusstop;
		this.arrivalBusstop = arrivalBusstop;
		this.availableSeats = availableSeats;
		this.departureDate = departureDate;
		this.arrivalDate = arrivalDate;
		this.arrivalTime = arrivalTime;
		this.departureTime = departureTime;
		this.busVendor = busVendor;
		this.cost = cost;
	}

}